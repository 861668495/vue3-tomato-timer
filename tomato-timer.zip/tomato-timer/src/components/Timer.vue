<template>
  <div :class="['container', isDark ? 'dark' : 'light']">
    <!-- 顶部导航 + 模式切换 -->
    <div class="header">
      <h1 class="title">番茄时钟</h1>
      <div class="theme-toggle">
        <van-switch v-model="isDark" size="20px" active-color="#000" inactive-color="#fff" />
        <span>{{ isDark ? '暗色模式' : '亮色模式' }}</span>
      </div>
    </div>

    <!-- 番茄钟卡片 -->
    <div class="timer-card">
      <div class="timer-wrapper">
        <van-circle
          v-model:current-rate="progress"
          :rate="100"
          :speed="100"
          :text="formatTime"
          :stroke-width="10"
          :color="{
            '0%': '#f66',
            '100%': '#3cc'
          }"
          layer-color="#e0e0e0"
          size="220px"
        />
        <div class="clock-bg" />
      </div>

      <div class="button-group">
        <van-button round block type="primary" @click="startTimer" :disabled="isRunning">▶ 开始</van-button>
        <van-button round block type="warning" @click="pauseTimer">⏸ 暂停</van-button>
        <van-button round block plain type="primary" hairline @click="resetTimer">🔄 重置</van-button>
      </div>

      <div class="sound-toggle">
        <van-switch v-model="soundEnabled" active-color="#07c160" />
        <span>音效提醒：{{ soundEnabled ? '开启' : '关闭' }}</span>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onUnmounted, watch } from 'vue'
import { Toast } from 'vant'
import 'vant/es/toast/style'

const totalTime = ref(25 * 60)
const remain = ref(25 * 60)
const isRunning = ref(false)
let timer = null

const isDark = ref(localStorage.getItem('theme') === 'dark')
const soundEnabled = ref(localStorage.getItem('sound') !== 'false')

const audio = new Audio('https://cdn.pixabay.com/download/audio/2021/09/20/audio_9c90e64842.mp3?filename=notification-132145.mp3')

watch(isDark, (val) => localStorage.setItem('theme', val ? 'dark' : 'light'))
watch(soundEnabled, (val) => localStorage.setItem('sound', val))

const startTimer = () => {
  if (isRunning.value) return
  isRunning.value = true
  timer = setInterval(() => {
    if (remain.value > 0) {
      remain.value--
    } else {
      clearInterval(timer)
      isRunning.value = false
      Toast.success('✅ 番茄时间结束！')
      if (soundEnabled.value) audio.play()
    }
  }, 1000)
}

const pauseTimer = () => {
  clearInterval(timer)
  isRunning.value = false
}

const resetTimer = () => {
  clearInterval(timer)
  remain.value = totalTime.value
  isRunning.value = false
}

onUnmounted(() => clearInterval(timer))

const formatTime = computed(() => {
  const min = Math.floor(remain.value / 60).toString().padStart(2, '0')
  const sec = (remain.value % 60).toString().padStart(2, '0')
  return `${min}:${sec}`
})

const progress = computed(() => {
  return ((totalTime.value - remain.value) / totalTime.value) * 100
})
</script>

<style scoped>
.container {
  min-height: 100vh;
  padding: 20px;
  display: flex;
  flex-direction: column;
  align-items: center;
  transition: background 0.3s ease;
}

.container.light {
  background: linear-gradient(to right, #fff1f0, #e6f7ff);
}

.container.dark {
  background: linear-gradient(to right, #141414, #1f1f1f);
}

.header {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 10px;
}

.title {
  font-size: 28px;
  font-weight: bold;
  color: #ff4d4f;
  letter-spacing: 2px;
}

.container.dark .title {
  color: #ffccc7;
}

.theme-toggle {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
}

.timer-card {
  background: rgba(255, 255, 255, 0.95);
  padding: 35px 30px;
  border-radius: 20px;
  box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
  width: 320px;
  margin-top: 30px;
  transition: all 0.3s ease;
}

.container.dark .timer-card {
  background: rgba(34, 34, 34, 0.95);
  color: white;
}

.timer-wrapper {
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 25px;
}

:deep(.van-circle__text) {
  font-size: 40px;
  font-weight: bold;
  color: #333;
}

.container.dark :deep(.van-circle__text) {
  color: white;
}

.clock-bg {
  position: absolute;
  width: 180px;
  height: 180px;
  background: radial-gradient(circle at center, #ffffff, #f0f0f0);
  border-radius: 50%;
  z-index: -1;
}

.button-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.sound-toggle {
  margin-top: 20px;
  display: flex;
  justify-content: center;
  gap: 10px;
  font-size: 14px;
}
</style>
