import { createApp } from 'vue'
import App from './App.vue'

import { createPinia } from 'pinia'
// 引入 Vant 样式
import 'vant/lib/index.css'

// 引入 Vant Progress 组件
import { Progress } from 'vant';

const app = createApp(App)
app.use(createPinia())
// 全局注册 Vant Progress 组件
app.use(Progress);
app.mount('#app')
