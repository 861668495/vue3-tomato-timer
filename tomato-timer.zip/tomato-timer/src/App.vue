<template>
  <Timer />
</template>

<script setup>
import Timer from './components/Timer.vue'
</script>
